d = {n : n+1 for n in range(0,11)}
print(d)

        
        
