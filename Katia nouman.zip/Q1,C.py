L=['Netwok','Bio','Programming','Physics','Music']
i=0
for i in range(len(L)):
    if L[i].startswith('B'):
        print(L[i])

