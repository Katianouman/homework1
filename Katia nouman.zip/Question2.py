Binary=input('enter a binary number')
try:
    x=int(Binary,2)
    print(x)
except:
    print('enter your correct number')


        
        
